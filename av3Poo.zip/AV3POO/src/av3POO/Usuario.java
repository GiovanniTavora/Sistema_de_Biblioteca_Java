package av3POO;

public interface Usuario {

	String getNome();
	void setNome(String nome);
}
