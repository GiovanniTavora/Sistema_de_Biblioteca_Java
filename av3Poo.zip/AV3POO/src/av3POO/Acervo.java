package av3POO;

public interface Acervo {
	String getTitulo();
	void setTitulo(String titulo);
	
	String getAutor();
}
