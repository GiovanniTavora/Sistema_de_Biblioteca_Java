module AV3POO {
	requires java.desktop;
}